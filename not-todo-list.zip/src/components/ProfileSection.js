import React from 'react'

const ProfileSection = () => {
  return (
    <div>ProfileSection</div>
  )
}

export default ProfileSection