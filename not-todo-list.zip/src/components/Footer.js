import { FooterContent, FooterText, FooterWrap } from "../style/FooterCSS"

const Footer = () => {
  return (
    <FooterWrap>
    <FooterContent> <FooterText>Footer</FooterText> </FooterContent>
    </FooterWrap>
  )
}
export default Footer