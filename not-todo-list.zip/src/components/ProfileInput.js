import React from 'react'

const ProfileInput = () => {
  return (
    <div>ProfileInput</div>
  )
}

export default ProfileInput